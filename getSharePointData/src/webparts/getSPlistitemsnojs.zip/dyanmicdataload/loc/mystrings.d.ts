declare interface IDyanmicdataloadWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DyanmicdataloadWebPartStrings' {
  const strings: IDyanmicdataloadWebPartStrings;
  export = strings;
}
