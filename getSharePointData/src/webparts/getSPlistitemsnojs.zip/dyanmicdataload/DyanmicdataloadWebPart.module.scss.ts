/* tslint:disable */
require("./DyanmicdataloadWebPart.module.css");
const styles = {
  dyanmicdataload: 'dyanmicdataload_195971e0',
  container: 'container_195971e0',
  row: 'row_195971e0',
  column: 'column_195971e0',
  'ms-Grid': 'ms-Grid_195971e0',
  title: 'title_195971e0',
  subTitle: 'subTitle_195971e0',
  description: 'description_195971e0',
  button: 'button_195971e0',
  label: 'label_195971e0',
  Table: 'Table_195971e0',
  Title: 'Title_195971e0',
  Heading: 'Heading_195971e0',
  Row: 'Row_195971e0',
  Cell: 'Cell_195971e0'
};

export default styles;
/* tslint:enable */