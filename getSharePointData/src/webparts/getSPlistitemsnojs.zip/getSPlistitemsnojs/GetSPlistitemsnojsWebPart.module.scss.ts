/* tslint:disable */
require("./GetSPlistitemsnojsWebPart.module.css");
const styles = {
  getSPlistitemsnojs: 'getSPlistitemsnojs_3c9a1043',
  container: 'container_3c9a1043',
  rtable: 'rtable_3c9a1043',
  rrow: 'rrow_3c9a1043',
  rheader: 'rheader_3c9a1043',
  rcell: 'rcell_3c9a1043'
};

export default styles;
/* tslint:enable */