declare interface IGetSPlistitemsnojsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GetSPlistitemsnojsWebPartStrings' {
  const strings: IGetSPlistitemsnojsWebPartStrings;
  export = strings;
}
